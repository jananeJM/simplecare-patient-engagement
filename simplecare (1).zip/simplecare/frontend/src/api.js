// api.js - small fetch wrapper for the SimpleCare backend (Review 1)
// The backend is a local FastAPI demo server serving only synthetic data.

const BASE_URL = 'http://localhost:8000'

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    let detail = 'Something went wrong. Please try again.'
    try {
      const body = await res.json()
      detail = body.detail || detail
    } catch (_) {
      /* ignore parse errors */
    }
    throw new Error(detail)
  }
  return res.json()
}

export const api = {
  login: (email, password) =>
    request('/api/login', { method: 'POST', body: JSON.stringify({ email, password }) }),

  getDashboard: (patientId) => request(`/api/patients/${patientId}/dashboard`),

  getProgress: (patientId) => request(`/api/patients/${patientId}/progress`),

  getGoal: (patientId) => request(`/api/patients/${patientId}/goal`),

  getConsent: (patientId) => request(`/api/patients/${patientId}/consent`),

  setConsent: (patientId, status) =>
    request(`/api/patients/${patientId}/consent`, {
      method: 'POST',
      body: JSON.stringify({ status }),
    }),

  getBaseline: (patientId) => request(`/api/patients/${patientId}/baseline`),
}
