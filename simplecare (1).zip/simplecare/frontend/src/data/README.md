# data/

For Review 1, synthetic data is generated and served by the backend
(see `backend/synthetic_data.py`) via the FastAPI endpoints in
`backend/main.py`. The frontend fetches this data over HTTP rather than
importing static JSON here, so that the same rule-based feedback engine
can run consistently no matter which screen calls it.

This folder is reserved for future local/offline demo fixtures if
needed in a later review.
