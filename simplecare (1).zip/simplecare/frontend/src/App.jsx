import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './AuthContext.jsx'
import RequireRole from './components/RequireRole.jsx'

import Login from './pages/Login.jsx'
import PatientLayout from './pages/PatientLayout.jsx'
import PatientDashboard from './pages/PatientDashboard.jsx'
import MyProgress from './pages/MyProgress.jsx'
import MyGoal from './pages/MyGoal.jsx'
import MyFeedback from './pages/MyFeedback.jsx'
import Privacy from './pages/Privacy.jsx'
import SimpleLayout from './pages/SimpleLayout.jsx'
import PlaceholderDashboard from './pages/PlaceholderDashboard.jsx'

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route
          path="/patient"
          element={
            <RequireRole role="patient">
              <PatientLayout />
            </RequireRole>
          }
        >
          <Route index element={<PatientDashboard />} />
          <Route path="progress" element={<MyProgress />} />
          <Route path="goal" element={<MyGoal />} />
          <Route path="feedback" element={<MyFeedback />} />
          <Route path="privacy" element={<Privacy />} />
        </Route>

        <Route
          path="/caregiver"
          element={
            <RequireRole role="caregiver">
              <SimpleLayout />
            </RequireRole>
          }
        >
          <Route index element={<PlaceholderDashboard roleLabel="Caregiver" />} />
        </Route>

        <Route
          path="/clinician"
          element={
            <RequireRole role="clinician">
              <SimpleLayout />
            </RequireRole>
          }
        >
          <Route index element={<PlaceholderDashboard roleLabel="Clinician" />} />
        </Route>

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </AuthProvider>
  )
}
