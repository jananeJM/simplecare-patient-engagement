import React from 'react'
import { NavLink } from 'react-router-dom'

const links = [
  { to: '/patient', label: 'Dashboard', end: true },
  { to: '/patient/progress', label: 'My Progress' },
  { to: '/patient/goal', label: 'My Goal' },
  { to: '/patient/feedback', label: 'My Feedback' },
  { to: '/patient/privacy', label: 'Privacy' },
]

export default function PatientNav() {
  return (
    <nav className="bottom-nav" aria-label="Patient navigation">
      {links.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          end={link.end}
          className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
        >
          {link.label}
        </NavLink>
      ))}
    </nav>
  )
}
