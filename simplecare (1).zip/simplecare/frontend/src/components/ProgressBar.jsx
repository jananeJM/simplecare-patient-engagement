import React from 'react'

export default function ProgressBar({ percent, label }) {
  const clamped = Math.max(0, Math.min(100, percent ?? 0))
  return (
    <div>
      <div className="progress-track" role="progressbar" aria-valuenow={clamped} aria-valuemin={0} aria-valuemax={100} aria-label={label || 'Progress'}>
        <div className="progress-fill" style={{ width: `${clamped}%` }} />
      </div>
      <p className="muted" style={{ margin: 0 }}>{clamped}%</p>
    </div>
  )
}
