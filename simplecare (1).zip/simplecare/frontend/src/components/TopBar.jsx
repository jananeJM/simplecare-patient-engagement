import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../AuthContext.jsx'

export default function TopBar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <header className="top-bar">
      <div className="brand">
        <span className="brand-mark">SimpleCare</span>
        <span className="demo-badge">Synthetic Demo Data</span>
      </div>
      {user && (
        <div className="top-bar-meta">
          <span>{user.email}</span>
          <button
            className="btn btn-outline"
            style={{ minHeight: 40, width: 'auto', padding: '6px 16px', fontSize: '0.95rem' }}
            onClick={handleLogout}
          >
            Log out
          </button>
        </div>
      )}
    </header>
  )
}
