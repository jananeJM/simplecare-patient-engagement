import React, { useEffect, useState } from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { api } from '../api.js'
import { useAuth } from '../AuthContext.jsx'

const trendToPill = {
  Improving: 'pill-improving',
  Stable: 'pill-stable',
  'Needs attention': 'pill-attention',
  'Not enough data': 'pill-missing',
}

export default function MyProgress() {
  const { user } = useAuth()
  const [weeks, setWeeks] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    api
      .getProgress(user.patient_id)
      .then((res) => active && setWeeks(res.weeks))
      .catch((e) => active && setError(e.message))
    return () => {
      active = false
    }
  }, [user.patient_id])

  if (error) return <div className="card error-banner">{error}</div>
  if (!weeks) return <div className="card">Loading your progress...</div>

  const chartData = weeks.map((w) => ({
    week: `Week ${w.week}`,
    adherence: w.adherence_percent,
  }))

  return (
    <div>
      <div className="card">
        <h2>My Progress</h2>
        <p className="muted">Here is how your last four weeks have gone.</p>

        <div style={{ width: '100%', height: 220, marginTop: 'var(--space-3)' }}>
          <ResponsiveContainer>
            <LineChart data={chartData} margin={{ top: 8, right: 16, bottom: 0, left: -16 }}>
              <CartesianGrid stroke="#E1DED2" strokeDasharray="4 4" />
              <XAxis dataKey="week" tick={{ fontSize: 13, fill: '#4B5A52' }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 13, fill: '#4B5A52' }} />
              <Tooltip formatter={(value) => (value === null ? 'No data' : `${value}%`)} />
              <Line
                type="monotone"
                dataKey="adherence"
                stroke="#3F7859"
                strokeWidth={3}
                dot={{ r: 5 }}
                connectNulls
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        {weeks.map((w) => (
          <div className="week-row" key={w.week}>
            <div>
              <p style={{ fontWeight: 700, margin: 0 }}>Week {w.week}</p>
              {w.has_data ? (
                <p className="muted" style={{ margin: 0 }}>
                  Adherence: {w.adherence_percent}% &middot; Goal: {Math.round(w.goal_progress_percent)}%
                </p>
              ) : (
                <p className="muted" style={{ margin: 0 }}>
                  We don't have enough recent information to describe your progress.
                </p>
              )}
            </div>
            <span className={`pill ${trendToPill[w.trend] || 'pill-missing'}`}>{w.trend}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
