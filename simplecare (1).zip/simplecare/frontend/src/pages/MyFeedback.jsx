import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import { useAuth } from '../AuthContext.jsx'

export default function MyFeedback() {
  const { user } = useAuth()
  const [dashboard, setDashboard] = useState(null)
  const [error, setError] = useState('')
  const [showWhy, setShowWhy] = useState(false)

  useEffect(() => {
    let active = true
    api
      .getDashboard(user.patient_id)
      .then((d) => active && setDashboard(d))
      .catch((e) => active && setError(e.message))
    return () => {
      active = false
    }
  }, [user.patient_id])

  if (error) return <div className="card error-banner">{error}</div>
  if (!dashboard) return <div className="card">Loading your feedback...</div>

  const { feedback } = dashboard

  return (
    <div>
      <div className="card">
        <h2>My Feedback</h2>
        <p style={{ fontSize: '1.2rem' }}>{feedback.message}</p>
        <button className="btn btn-outline" onClick={() => setShowWhy((v) => !v)}>
          Why am I seeing this?
        </button>
        {showWhy && (
          <p className="muted" style={{ marginTop: 'var(--space-2)' }}>
            {feedback.explanation}
          </p>
        )}
      </div>

      <div className="card card-tight">
        <h3 style={{ fontSize: '1rem' }}>How this feedback is created</h3>
        <p className="muted" style={{ margin: 0 }}>
          This message comes from simple, transparent rules that look at your recent
          activity compared to the week before. It is not created by a clinician and it
          never suggests changing any treatment.
        </p>
      </div>
    </div>
  )
}
