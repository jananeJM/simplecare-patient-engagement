import React from 'react'

export default function PlaceholderDashboard({ roleLabel }) {
  return (
    <div className="card" style={{ textAlign: 'center', padding: 'var(--space-6) var(--space-4)' }}>
      <h2>{roleLabel} Dashboard</h2>
      <p className="muted" style={{ fontSize: '1.1rem' }}>
        This dashboard will be expanded in the next development phase.
      </p>
    </div>
  )
}
