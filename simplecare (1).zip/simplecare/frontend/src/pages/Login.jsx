import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api.js'
import { useAuth } from '../AuthContext.jsx'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const result = await api.login(email, password)
      login(result)
      if (result.role === 'patient') navigate('/patient')
      else if (result.role === 'caregiver') navigate('/caregiver')
      else navigate('/clinician')
    } catch (err) {
      setError(err.message || 'Could not log in. Please check your email and password.')
    } finally {
      setLoading(false)
    }
  }

  const fillDemo = (demoEmail, demoPassword) => {
    setEmail(demoEmail)
    setPassword(demoPassword)
  }

  return (
    <div className="login-shell">
      <div className="card login-card">
        <div className="brand" style={{ marginBottom: 'var(--space-3)' }}>
          <span className="brand-mark">SimpleCare</span>
        </div>
        <p className="muted">Sign in to see your progress and feedback.</p>

        {error && <div className="error-banner">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="username"
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />
          </div>
          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>

        <div className="demo-accounts">
          <p style={{ fontWeight: 700, marginBottom: 8 }}>Demo accounts</p>
          <p style={{ margin: '4px 0' }}>
            Patient: patient@simplecare.demo / patient123{' '}
            <button
              type="button"
              onClick={() => fillDemo('patient@simplecare.demo', 'patient123')}
              style={{ marginLeft: 8, cursor: 'pointer' }}
            >
              Use
            </button>
          </p>
          <p style={{ margin: '4px 0' }}>
            Caregiver: caregiver@simplecare.demo / caregiver123{' '}
            <button
              type="button"
              onClick={() => fillDemo('caregiver@simplecare.demo', 'caregiver123')}
              style={{ marginLeft: 8, cursor: 'pointer' }}
            >
              Use
            </button>
          </p>
          <p style={{ margin: '4px 0' }}>
            Clinician: clinician@simplecare.demo / clinician123{' '}
            <button
              type="button"
              onClick={() => fillDemo('clinician@simplecare.demo', 'clinician123')}
              style={{ marginLeft: 8, cursor: 'pointer' }}
            >
              Use
            </button>
          </p>
        </div>
      </div>
    </div>
  )
}
