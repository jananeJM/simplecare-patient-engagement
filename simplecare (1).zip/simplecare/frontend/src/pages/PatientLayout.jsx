import React from 'react'
import { Outlet } from 'react-router-dom'
import TopBar from '../components/TopBar.jsx'
import PatientNav from '../components/PatientNav.jsx'

export default function PatientLayout() {
  return (
    <div className="app-shell">
      <TopBar />
      <main className="page-content">
        <Outlet />
      </main>
      <PatientNav />
    </div>
  )
}
