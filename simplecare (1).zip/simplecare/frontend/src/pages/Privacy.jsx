import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import { useAuth } from '../AuthContext.jsx'

export default function Privacy() {
  const { user } = useAuth()
  const [consentStatus, setConsentStatus] = useState(null)
  const [understood, setUnderstood] = useState(false)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    let active = true
    api
      .getConsent(user.patient_id)
      .then((res) => active && setConsentStatus(res.consent_status))
      .catch((e) => active && setError(e.message))
    return () => {
      active = false
    }
  }, [user.patient_id])

  const updateConsent = async (status) => {
    setSaving(true)
    setError('')
    try {
      const res = await api.setConsent(user.patient_id, status)
      setConsentStatus(res.consent_status)
    } catch (e) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="card">
        <h2>How we use your information</h2>
        <ul style={{ paddingLeft: '1.2em', margin: 0 }}>
          <li>We use your activity information to show your progress.</li>
          <li>Only authorized people should see your information.</li>
          <li>This prototype uses synthetic demonstration data.</li>
          <li>This is not a real clinical system.</li>
        </ul>
      </div>

      {error && <div className="card error-banner">{error}</div>}

      <div className="card">
        <p>
          Current status:{' '}
          <strong>{consentStatus === 'given' ? 'Consent given' : consentStatus === 'withdrawn' ? 'Consent withdrawn' : 'Loading...'}</strong>
        </p>

        {consentStatus === 'withdrawn' && (
          <p className="muted">
            Your consent has been withdrawn. Your participation data is no longer being
            used to create new feedback.
          </p>
        )}

        <label className="checkbox-row">
          <input
            type="checkbox"
            checked={understood}
            onChange={(e) => setUnderstood(e.target.checked)}
          />
          <span>I understand how my information is used.</span>
        </label>

        <div className="btn-stack">
          <button
            className="btn btn-primary"
            disabled={!understood || saving || consentStatus === 'given'}
            onClick={() => updateConsent('given')}
          >
            Give Consent
          </button>
          <button
            className="btn btn-danger-outline"
            disabled={saving || consentStatus === 'withdrawn'}
            onClick={() => updateConsent('withdrawn')}
          >
            Withdraw Consent
          </button>
        </div>
      </div>
    </div>
  )
}
