import React from 'react'
import { Outlet } from 'react-router-dom'
import TopBar from '../components/TopBar.jsx'

export default function SimpleLayout() {
  return (
    <div className="app-shell">
      <TopBar />
      <main className="page-content">
        <Outlet />
      </main>
      <p className="footer-note">Synthetic Demo Data – Not for Clinical Use</p>
    </div>
  )
}
