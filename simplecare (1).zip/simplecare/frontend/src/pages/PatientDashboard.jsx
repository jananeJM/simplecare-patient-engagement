import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import { useAuth } from '../AuthContext.jsx'

const categoryToPill = {
  improving: 'pill-improving',
  stable: 'pill-stable',
  declining: 'pill-attention',
  missing_data: 'pill-missing',
  consent_withdrawn: 'pill-missing',
}

export default function PatientDashboard() {
  const { user } = useAuth()
  const [dashboard, setDashboard] = useState(null)
  const [error, setError] = useState('')
  const [showWhy, setShowWhy] = useState(false)

  useEffect(() => {
    let active = true
    api
      .getDashboard(user.patient_id)
      .then((d) => active && setDashboard(d))
      .catch((e) => active && setError(e.message))
    return () => {
      active = false
    }
  }, [user.patient_id])

  if (error) {
    return <div className="card error-banner">{error}</div>
  }

  if (!dashboard) {
    return <div className="card">Loading your dashboard...</div>
  }

  const { greeting, feedback, goal, activities_summary: activitiesSummary } = dashboard
  const goalPercent = goal?.target
    ? Math.min(Math.round((goal.current_value / goal.target) * 100), 100)
    : 0

  return (
    <div>
      <div className="card">
        <div className="greeting">{greeting}</div>
        <h2>Your progress this week</h2>
        <p>
          <span className={`pill ${categoryToPill[feedback.category] || 'pill-stable'}`}>
            {feedback.category === 'improving' && 'Improving'}
            {feedback.category === 'stable' && 'Stable'}
            {feedback.category === 'declining' && 'Needs attention'}
            {feedback.category === 'missing_data' && 'Not enough data'}
            {feedback.category === 'consent_withdrawn' && 'Consent withdrawn'}
          </span>
        </p>
        <p style={{ fontSize: '1.15rem' }}>{feedback.message}</p>

        <button className="btn btn-outline" onClick={() => setShowWhy((v) => !v)}>
          Why am I seeing this?
        </button>
        {showWhy && (
          <p className="muted" style={{ marginTop: 'var(--space-2)' }}>
            {feedback.explanation}
          </p>
        )}
      </div>

      <div className="card">
        <h3>Your personal goal</h3>
        <p style={{ fontSize: '1.15rem', fontWeight: 700 }}>{goal?.goal_name}</p>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${goalPercent}%` }} />
        </div>
        <p className="muted">{goalPercent}% of the way there</p>
        {activitiesSummary && <p>{activitiesSummary}</p>}
        <p style={{ fontWeight: 700 }}>Next small step: Try to complete one more activity.</p>
      </div>

      <div className="btn-stack">
        <Link className="btn btn-secondary" to="/patient/progress">
          See My Progress
        </Link>
        <Link className="btn btn-secondary" to="/patient/goal">
          My Goal
        </Link>
        <Link className="btn btn-secondary" to="/patient/privacy">
          Privacy
        </Link>
      </div>
    </div>
  )
}
