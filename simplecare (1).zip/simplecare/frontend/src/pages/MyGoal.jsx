import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import { useAuth } from '../AuthContext.jsx'
import ProgressBar from '../components/ProgressBar.jsx'

export default function MyGoal() {
  const { user } = useAuth()
  const [goal, setGoal] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    api
      .getGoal(user.patient_id)
      .then((res) => active && setGoal(res))
      .catch((e) => active && setError(e.message))
    return () => {
      active = false
    }
  }, [user.patient_id])

  if (error) return <div className="card error-banner">{error}</div>
  if (!goal) return <div className="card">Loading your goal...</div>

  return (
    <div>
      <div className="card">
        <h2>Your Goal</h2>
        <p style={{ fontSize: '1.3rem', fontWeight: 700 }}>"{goal.goal_name}"</p>
        <p className="muted">
          {goal.current_value} / {goal.target} days
        </p>
        <ProgressBar percent={goal.percent} label="Goal progress" />
        <p style={{ fontSize: '1.1rem' }}>{goal.message}</p>
      </div>

      <div className="card card-tight">
        <p className="muted" style={{ margin: 0 }}>
          {goal.editing_note}
        </p>
      </div>
    </div>
  )
}
