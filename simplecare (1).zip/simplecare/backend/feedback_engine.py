"""
feedback_engine.py

Review 1 scope: a FIRST VERSION, fully transparent, RULE-BASED feedback
engine. No AI / machine learning is used anywhere in this module.

Design principles (see docs/review1_report.md, section 10):
- Never diagnose a medical condition.
- Never recommend changing a treatment or medication.
- Always be explainable: every message can be traced back to a simple rule.
- Never fabricate improvement when data is missing.
"""

from typing import Dict, Any, List, Optional


def _latest_two_adherence(adherence_history: List[Dict[str, Any]]) -> Optional[List[Dict[str, Any]]]:
    """Return the two most recent weeks of adherence data, if available."""
    if len(adherence_history) < 2:
        return None
    return adherence_history[-2:]


def generate_feedback(adherence_history: List[Dict[str, Any]]) -> Dict[str, str]:
    """
    Apply simple, transparent rules to the two most recent weeks of
    adherence data and return a plain-language feedback message.

    Returns a dict with:
      - message: the feedback text shown to the patient
      - category: one of "improving" | "stable" | "declining" | "missing_data"
      - explanation: short plain-language reason ("Why am I seeing this?")
    """
    recent = _latest_two_adherence(adherence_history)

    if recent is None:
        return {
            "message": "We don't have enough information this week to show your full progress.",
            "category": "missing_data",
            "explanation": "We looked at your recent activity and your goal to create this message.",
        }

    previous_week, current_week = recent

    prev_rate = previous_week.get("adherence_rate")
    curr_rate = current_week.get("adherence_rate")

    # Edge case: missing data for either of the two most recent weeks.
    if prev_rate is None or curr_rate is None:
        return {
            "message": "We don't have enough recent information to describe your progress.",
            "category": "missing_data",
            "explanation": "We looked at your recent activity and your goal to create this message.",
        }

    difference = curr_rate - prev_rate

    # Simple, explainable thresholds (Review 1 uses a flat 5% band as "similar").
    if difference > 0.05:
        message = "You followed your care plan more often this week. That's a good step forward."
        category = "improving"
    elif difference < -0.05:
        message = "You missed some planned activities this week. Let's focus on one small step next week."
        category = "declining"
    else:
        message = "Your progress is staying about the same this week. Keep taking one step at a time."
        category = "stable"

    return {
        "message": message,
        "category": category,
        "explanation": "We looked at your recent activity and your goal to create this message.",
    }


def generate_baseline_message() -> Dict[str, str]:
    """
    Review 1: a single, non-personalized baseline message.

    Future review: this will be compared against the personalized,
    rule-based feedback above across an 8-week synthetic experiment
    to evaluate whether personalized feedback improves engagement.
    """
    return {
        "message": "This week your activity was recorded. Please continue following your care plan.",
        "category": "baseline",
        "explanation": "This is a general reminder shown to everyone, and does not use your personal activity data.",
    }
