"""
main.py - SimpleCare backend (Review 1)

Synthetic Demo Data - Not for Clinical Use.

Run with:
    uvicorn main:app --reload

This is a Review-1 prototype backend. Authentication below is a simple
DEMO login (hard-coded synthetic accounts, no password hashing, no
sessions/JWT) and is explicitly NOT production-ready. Full role-based
authorization is listed as pending work in docs/review1_report.md.
"""

from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import synthetic_data as data
import feedback_engine

app = FastAPI(
    title="SimpleCare API (Review 1 Prototype)",
    description="Synthetic Demo Data - Not for Clinical Use.",
    version="0.1.0-review1",
)

# Allow the Vite dev server to call this API during local development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Demo accounts (Review 1 only - see README for full disclaimer)
# ---------------------------------------------------------------------------

DEMO_USERS = {
    "patient@simplecare.demo": {
        "password": "patient123",
        "role": "patient",
        "patient_id": "P001",  # demo login maps to the "consistently engaged" persona
    },
    "caregiver@simplecare.demo": {
        "password": "caregiver123",
        "role": "caregiver",
        "patient_id": None,
    },
    "clinician@simplecare.demo": {
        "password": "clinician123",
        "role": "clinician",
        "patient_id": None,
    },
}


class LoginRequest(BaseModel):
    email: str
    password: str


class ConsentRequest(BaseModel):
    status: str  # "given" or "withdrawn"


@app.get("/")
def root():
    return {
        "service": "SimpleCare API",
        "status": "ok",
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
    }


@app.post("/api/login")
def login(payload: LoginRequest):
    user = DEMO_USERS.get(payload.email.lower().strip())
    if not user or user["password"] != payload.password:
        raise HTTPException(status_code=401, detail="Invalid demo credentials.")
    return {
        "email": payload.email.lower().strip(),
        "role": user["role"],
        "patient_id": user["patient_id"],
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
    }


def _require_patient(patient_id: str):
    try:
        return data.get_patient(patient_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Unknown synthetic patient_id.")


@app.get("/api/patients/{patient_id}/dashboard")
def patient_dashboard(patient_id: str):
    """
    Aggregated view for the patient dashboard home screen:
    latest goal, latest adherence-based feedback (or baseline, if consent
    has been withdrawn), and a short plain-language summary.
    """
    profile = _require_patient(patient_id)
    consent_status = data.get_consent(patient_id)
    goal = data.get_goal(patient_id)
    adherence_history = data.get_adherence(patient_id)

    if consent_status == "withdrawn":
        feedback = {
            "message": "Your consent has been withdrawn. Your participation data is no longer being used to create new feedback.",
            "category": "consent_withdrawn",
            "explanation": "You chose to withdraw consent, so we are not analyzing new activity data.",
        }
    else:
        feedback = feedback_engine.generate_feedback(adherence_history)

    latest_adherence = adherence_history[-1] if adherence_history else None
    activities_summary = None
    if latest_adherence and latest_adherence.get("completed_events") is not None:
        activities_summary = f"{latest_adherence['completed_events']} of {latest_adherence['expected_events']} activities completed"

    return {
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
        "patient": profile,
        "consent_status": consent_status,
        "greeting": "Good morning \U0001F44B",
        "goal": goal,
        "feedback": feedback,
        "activities_summary": activities_summary,
        "latest_adherence": latest_adherence,
    }


@app.get("/api/patients/{patient_id}/progress")
def patient_progress(patient_id: str):
    """Four weeks of adherence + goal progress + simple trend label."""
    _require_patient(patient_id)
    adherence_history = data.get_adherence(patient_id)
    monitoring_history = data.get_monitoring(patient_id)
    goal = data.get_goal(patient_id)

    monitoring_by_week = {m["week"]: m for m in monitoring_history}

    weeks = []
    for entry in adherence_history:
        week_num = entry["week"]
        monitoring_entry = monitoring_by_week.get(week_num, {})
        adherence_rate = entry.get("adherence_rate")

        if adherence_rate is None:
            trend_label = "Not enough data"
        else:
            trend_label = {
                "improving": "Improving",
                "stable": "Stable",
                "declining": "Needs attention",
                "unknown": "Not enough data",
            }.get(monitoring_entry.get("trend", "stable"), "Stable")

        weeks.append(
            {
                "week": week_num,
                "adherence_percent": round(adherence_rate * 100) if adherence_rate is not None else None,
                "goal_progress_percent": goal.get("current_value", 0) / goal.get("target", 1) * 100
                if goal.get("target")
                else None,
                "trend": trend_label,
                "has_data": adherence_rate is not None,
            }
        )

    return {
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
        "weeks": weeks,
    }


@app.get("/api/patients/{patient_id}/goal")
def patient_goal(patient_id: str):
    _require_patient(patient_id)
    goal = data.get_goal(patient_id)
    if not goal:
        raise HTTPException(status_code=404, detail="No goal set for this patient.")
    target = goal.get("target") or 1
    current = goal.get("current_value") or 0
    percent = min(round((current / target) * 100), 100)

    if percent >= 100:
        message = "Great job! You reached your goal."
    elif percent >= 70:
        message = "You are close to your goal."
    elif percent >= 30:
        message = "You are making progress toward your goal."
    else:
        message = "Let's work on taking a few more small steps toward your goal."

    return {
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
        "goal_name": goal["goal_name"],
        "target": target,
        "current_value": current,
        "percent": percent,
        "message": message,
        "editing_supported": False,
        "editing_note": "Goal creation and editing will be available in a future development phase.",
    }


@app.get("/api/patients/{patient_id}/consent")
def get_consent(patient_id: str):
    _require_patient(patient_id)
    return {
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
        "consent_status": data.get_consent(patient_id),
    }


@app.post("/api/patients/{patient_id}/consent")
def update_consent(patient_id: str, payload: ConsentRequest):
    _require_patient(patient_id)
    try:
        new_status = data.set_consent(patient_id, payload.status)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
        "consent_status": new_status,
    }


@app.get("/api/patients/{patient_id}/baseline")
def baseline_message(patient_id: str):
    """
    Review 1: returns the single non-personalized baseline message.
    Not wired into the main dashboard yet - reserved for the future
    baseline-vs-personalized experiment (see docs/review1_report.md).
    """
    _require_patient(patient_id)
    return {
        "notice": data.SYNTHETIC_DATA_DISCLAIMER,
        "baseline": feedback_engine.generate_baseline_message(),
    }
