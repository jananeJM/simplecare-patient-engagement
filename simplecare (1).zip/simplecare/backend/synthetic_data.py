"""
synthetic_data.py

Generates SYNTHETIC / DEMO patient data for SimpleCare (Review 1).

IMPORTANT:
- No real patient data is used anywhere in this file or in this project.
- All patient names, IDs, and metrics below are fabricated for demonstration
  purposes only, to exercise the dashboard and feedback engine.
- Review 1 scope: 3 synthetic patients, 4 weeks of history each.
  (Later reviews will expand this to 7+ profiles and 8 weeks.)
"""

from typing import Dict, List, Any

SYNTHETIC_DATA_DISCLAIMER = "Synthetic Demo Data \u2013 Not for Clinical Use"

# ---------------------------------------------------------------------------
# 1. Patient profiles
# ---------------------------------------------------------------------------

PATIENTS: List[Dict[str, Any]] = [
    {
        "patient_id": "P001",
        "display_name": "Demo Patient (Consistently Engaged)",
        "age_group": "70-79",
        "digital_confidence_level": "medium",
        "consent_status": "given",
    },
    {
        "patient_id": "P002",
        "display_name": "Demo Patient (Improving Adherence)",
        "age_group": "65-74",
        "digital_confidence_level": "low",
        "consent_status": "given",
    },
    {
        "patient_id": "P003",
        "display_name": "Demo Patient (Low Digital Confidence)",
        "age_group": "80-89",
        "digital_confidence_level": "very_low",
        "consent_status": "given",
    },
]

# ---------------------------------------------------------------------------
# 2. Monitoring data (weekly activity metric, synthetic "steps-like" measure)
# ---------------------------------------------------------------------------

MONITORING: Dict[str, List[Dict[str, Any]]] = {
    "P001": [
        {"week": 1, "metric": "daily_activity_minutes", "value": 35, "trend": "stable"},
        {"week": 2, "metric": "daily_activity_minutes", "value": 38, "trend": "improving"},
        {"week": 3, "metric": "daily_activity_minutes", "value": 40, "trend": "improving"},
        {"week": 4, "metric": "daily_activity_minutes", "value": 41, "trend": "stable"},
    ],
    "P002": [
        {"week": 1, "metric": "daily_activity_minutes", "value": 15, "trend": "stable"},
        {"week": 2, "metric": "daily_activity_minutes", "value": 20, "trend": "improving"},
        {"week": 3, "metric": "daily_activity_minutes", "value": 27, "trend": "improving"},
        {"week": 4, "metric": "daily_activity_minutes", "value": 30, "trend": "improving"},
    ],
    "P003": [
        {"week": 1, "metric": "daily_activity_minutes", "value": 18, "trend": "stable"},
        {"week": 2, "metric": "daily_activity_minutes", "value": None, "trend": "unknown"},  # missing data edge case
        {"week": 3, "metric": "daily_activity_minutes", "value": 16, "trend": "declining"},
        {"week": 4, "metric": "daily_activity_minutes", "value": 14, "trend": "declining"},
    ],
}

# ---------------------------------------------------------------------------
# 3. Goals
# ---------------------------------------------------------------------------

GOALS: Dict[str, Dict[str, Any]] = {
    "P001": {
        "goal_name": "Stay active 4 days this week",
        "target": 4,
        "current_value": 4,
        "status": "met",
    },
    "P002": {
        "goal_name": "Stay active 4 days this week",
        "target": 4,
        "current_value": 3,
        "status": "on_track",
    },
    "P003": {
        "goal_name": "Stay active 4 days this week",
        "target": 4,
        "current_value": 1,
        "status": "needs_attention",
    },
}

# ---------------------------------------------------------------------------
# 4. Adherence (planned vs completed care-plan activities)
# ---------------------------------------------------------------------------

ADHERENCE: Dict[str, List[Dict[str, Any]]] = {
    "P001": [
        {"week": 1, "expected_events": 5, "completed_events": 4, "adherence_rate": 0.80},
        {"week": 2, "expected_events": 5, "completed_events": 4, "adherence_rate": 0.80},
        {"week": 3, "expected_events": 5, "completed_events": 5, "adherence_rate": 1.00},
        {"week": 4, "expected_events": 5, "completed_events": 4, "adherence_rate": 0.80},
    ],
    "P002": [
        {"week": 1, "expected_events": 5, "completed_events": 2, "adherence_rate": 0.40},
        {"week": 2, "expected_events": 5, "completed_events": 3, "adherence_rate": 0.60},
        {"week": 3, "expected_events": 5, "completed_events": 3, "adherence_rate": 0.60},
        {"week": 4, "expected_events": 5, "completed_events": 4, "adherence_rate": 0.80},
    ],
    "P003": [
        {"week": 1, "expected_events": 5, "completed_events": 2, "adherence_rate": 0.40},
        {"week": 2, "expected_events": 5, "completed_events": None, "adherence_rate": None},  # missing data
        {"week": 3, "expected_events": 5, "completed_events": 1, "adherence_rate": 0.20},
        {"week": 4, "expected_events": 5, "completed_events": 1, "adherence_rate": 0.20},
    ],
}

# ---------------------------------------------------------------------------
# 5. Engagement (app usage - not yet surfaced in UI, reserved for later review)
# ---------------------------------------------------------------------------

ENGAGEMENT: Dict[str, List[Dict[str, Any]]] = {
    "P001": [
        {"week": 1, "app_sessions": 5, "feedback_viewed": 5},
        {"week": 2, "app_sessions": 6, "feedback_viewed": 6},
        {"week": 3, "app_sessions": 6, "feedback_viewed": 5},
        {"week": 4, "app_sessions": 5, "feedback_viewed": 5},
    ],
    "P002": [
        {"week": 1, "app_sessions": 2, "feedback_viewed": 1},
        {"week": 2, "app_sessions": 3, "feedback_viewed": 3},
        {"week": 3, "app_sessions": 4, "feedback_viewed": 3},
        {"week": 4, "app_sessions": 4, "feedback_viewed": 4},
    ],
    "P003": [
        {"week": 1, "app_sessions": 1, "feedback_viewed": 1},
        {"week": 2, "app_sessions": 0, "feedback_viewed": 0},
        {"week": 3, "app_sessions": 1, "feedback_viewed": 0},
        {"week": 4, "app_sessions": 1, "feedback_viewed": 0},
    ],
}

# ---------------------------------------------------------------------------
# 6. Consent state (in-memory mock store, resets on server restart)
# ---------------------------------------------------------------------------
# NOTE: This is a Review-1 mock only. A real system would persist consent
# in a proper database with an audit trail.

CONSENT_STATE: Dict[str, str] = {p["patient_id"]: p["consent_status"] for p in PATIENTS}


def get_patient(patient_id: str) -> Dict[str, Any]:
    for p in PATIENTS:
        if p["patient_id"] == patient_id:
            return p
    raise KeyError(f"Unknown synthetic patient_id: {patient_id}")


def get_monitoring(patient_id: str) -> List[Dict[str, Any]]:
    return MONITORING.get(patient_id, [])


def get_goal(patient_id: str) -> Dict[str, Any]:
    return GOALS.get(patient_id, {})


def get_adherence(patient_id: str) -> List[Dict[str, Any]]:
    return ADHERENCE.get(patient_id, [])


def get_engagement(patient_id: str) -> List[Dict[str, Any]]:
    return ENGAGEMENT.get(patient_id, [])


def get_consent(patient_id: str) -> str:
    return CONSENT_STATE.get(patient_id, "unknown")


def set_consent(patient_id: str, status: str) -> str:
    if status not in ("given", "withdrawn"):
        raise ValueError("status must be 'given' or 'withdrawn'")
    CONSENT_STATE[patient_id] = status
    return CONSENT_STATE[patient_id]
